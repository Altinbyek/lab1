package week2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Font;
import java.awt.Window.Type;
import java.awt.Dialog.ModalExclusionType;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Panel;
import javax.swing.ButtonGroup;
import javax.swing.SwingConstants;

public class Calculator {

	private JFrame calc;
	private JTextField txt;
	
	double first;
	double second;
	double result;
	String operation;
	String answer;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculator window = new Calculator();
					window.calc.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Calculator() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		calc = new JFrame();
		calc.setType(Type.POPUP);
		calc.setFont(new Font("Arial", Font.PLAIN, 16));
		calc.setBackground(Color.GRAY);
		calc.setTitle("Тооны машин");
		calc.setBounds(100, 100, 297, 350);
		calc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblNewLabel = new JLabel("Тооны машин В190910044");
		lblNewLabel.setBounds(20, 0, 257, 27);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		txt = new JTextField();
		txt.setHorizontalAlignment(SwingConstants.RIGHT);
		txt.setEnabled(false);
		txt.setFont(new Font("Tahoma", Font.BOLD, 14));
		txt.setBounds(10, 24, 256, 34);
		txt.setColumns(10);
		
		final JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn0.getText();
				txt.setText(number);
				
			}
		});
		btn0.setEnabled(false);
		btn0.setBounds(10, 266, 113, 37);
		btn0.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn1 = new JButton("1");
		btn1.setEnabled(false);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn1.getText();
				txt.setText(number);
			}
		});
		btn1.setBounds(10, 221, 51, 34);
		btn1.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn2 = new JButton("2");
		btn2.setEnabled(false);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn2.getText();
				txt.setText(number);
			}
		});
		btn2.setBounds(71, 221, 51, 34);
		btn2.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn7 = new JButton("7");
		btn7.setEnabled(false);
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn7.getText();
				txt.setText(number);
			}
		});
		btn7.setBounds(10, 131, 51, 34);
		btn7.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn8 = new JButton("8");
		btn8.setEnabled(false);
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn8.getText();
				txt.setText(number);
			}
		});
		btn8.setBounds(71, 131, 51, 34);
		btn8.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn9 = new JButton("9");
		btn9.setEnabled(false);
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn9.getText();
				txt.setText(number);
			}
		});
		btn9.setBounds(132, 131, 51, 34);
		btn9.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton tseg = new JButton(".");
		tseg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + tseg.getText();
				txt.setText(number);
			}
		});
		tseg.setEnabled(false);
		tseg.setBounds(133, 266, 51, 37);
		tseg.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn4 = new JButton("4");
		btn4.setEnabled(false);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn4.getText();
				txt.setText(number);
			}
		});
		btn4.setBounds(10, 176, 51, 34);
		btn4.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn5 = new JButton("5");
		btn5.setEnabled(false);
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn5.getText();
				txt.setText(number);
			}
		});
		btn5.setBounds(71, 176, 51, 34);
		btn5.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn3 = new JButton("3");
		btn3.setEnabled(false);
		btn3.setBounds(132, 221, 51, 34);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn3.getText();
				txt.setText(number);
			}
		});
		btn3.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btn6 = new JButton("6");
		btn6.setEnabled(false);
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String number = txt.getText() + btn6.getText();
				txt.setText(number);
			}
		});
		btn6.setBounds(132, 176, 51, 34);
		btn6.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton sum = new JButton("+");
		sum.setEnabled(false);
		sum.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				first = Double.parseDouble(txt.getText());
				txt.setText("");
				operation = "+";
			}
		});
		sum.setBounds(193, 131, 73, 28);
		sum.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btnB = new JButton("\uF0E7");
		btnB.setEnabled(false);
		btnB.setBounds(203, 95, 63, 34);
		btnB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String B = null;
				if(txt.getText().length()>0)
				{
					StringBuilder str = new StringBuilder(txt.getText());
					str.deleteCharAt(txt.getText().length()-1);
					B = str.toString();
					txt.setText(B);
					
				}
			}
			
		});
		btnB.setFont(new Font("Wingdings", Font.BOLD, 18));
		
		final JButton btnC = new JButton("C");
		btnC.setEnabled(false);
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txt.setText(null);
			}
		});
		btnC.setBounds(10, 94, 51, 34);
		btnC.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton btnPow = new JButton("x^2");
		btnPow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double a = Double.parseDouble(txt.getText());
				a = a * a;
				txt.setText("");
				txt.setText(txt.getText()+a);
			}
		});
		btnPow.setEnabled(false);
		btnPow.setBounds(65, 94, 63, 34);
		btnPow.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		final JButton btnSqrt = new JButton("sqrt");
		btnSqrt.setEnabled(false);
		btnSqrt.setBounds(132, 95, 67, 34);
		btnSqrt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double a = Math.sqrt(Double.parseDouble(txt.getText()));
				txt.setText("");
				txt.setText(txt.getText()+a);
			}
		});
		btnSqrt.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		final JButton hasah = new JButton("-");
		hasah.setEnabled(false);
		hasah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				first = Double.parseDouble(txt.getText());
				txt.setText("");
				operation = "-";
			}
		});
		hasah.setBounds(193, 170, 73, 28);
		hasah.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton multiple = new JButton("*");
		multiple.setEnabled(false);
		multiple.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				first = Double.parseDouble(txt.getText());
				txt.setText("");
				operation = "*";
			}
		});
		multiple.setBounds(193, 206, 73, 28);
		multiple.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton hubaah = new JButton("/");
		hubaah.setEnabled(false);
		hubaah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				first = Double.parseDouble(txt.getText());
				txt.setText("");
				operation = "/";
			}
		});
		hubaah.setBounds(193, 242, 73, 28);
		hubaah.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JButton tensuu = new JButton("=");
		tensuu.setEnabled(false);
		tensuu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				second = Double.parseDouble(txt.getText());
				if(operation == "+")
				{
					result = first + second;
					answer = String.format("%.2f", result);
					txt.setText(answer);
				}
				else if(operation == "-")
				{
					result = first - second;
					answer = String.format("%.2f", result);
					txt.setText(answer);
				}
				else if(operation == "*")
				{
					result = first * second;
					answer = String.format("%.2f", result);
					txt.setText(answer);
				}
				else if(operation == "/")
				{
					if(second != 0) {
					result = first / second;
					answer = String.format("%.2f", result);
					txt.setText(answer);
					}else txt.setText("Тоог тэгт хувааж болохгүй!!!");
				}
			}
		});
		tensuu.setBounds(193, 275, 73, 28);
		tensuu.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		final JRadioButton on = new JRadioButton("ON");
		on.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btn1.setEnabled(true);
				btn2.setEnabled(true);
				btn3.setEnabled(true);
				btn4.setEnabled(true);
				btn5.setEnabled(true);
				btn6.setEnabled(true);
				btn7.setEnabled(true);
				btn8.setEnabled(true);
				btn9.setEnabled(true);
				multiple.setEnabled(true);
				hasah.setEnabled(true);
				tseg.setEnabled(true);
				hubaah.setEnabled(true);
				sum.setEnabled(true);
				btnB.setEnabled(true);
				btnC.setEnabled(true);
				btnSqrt.setEnabled(true);
				btnPow.setEnabled(true);
				tensuu.setEnabled(true);
				btn0.setEnabled(true);
				txt.setEnabled(true);
				
			}
		});
		buttonGroup.add(on);
		on.setBounds(10, 64, 57, 23);
		on.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		final JRadioButton off = new JRadioButton("OFF");
		off.setSelected(true);
		off.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				btn1.setEnabled(false);
				btn2.setEnabled(false);
				btn3.setEnabled(false);
				btn4.setEnabled(false);
				btn5.setEnabled(false);
				btn6.setEnabled(false);
				btn7.setEnabled(false);
				btn8.setEnabled(false);
				btn9.setEnabled(false);
				multiple.setEnabled(false);
				hasah.setEnabled(false);
				tseg.setEnabled(false);
				hubaah.setEnabled(false);
				sum.setEnabled(false);
				btnB.setEnabled(false);
				btnC.setEnabled(false);
				btnSqrt.setEnabled(false);
				btnPow.setEnabled(false);
				tensuu.setEnabled(false);
				btn0.setEnabled(false);
				txt.setEnabled(false);
				
			}
		});
		buttonGroup.add(off);
		off.setBounds(209, 65, 57, 23);
		off.setFont(new Font("Tahoma", Font.BOLD, 12));
		calc.getContentPane().setLayout(null);
		calc.getContentPane().add(txt);
		calc.getContentPane().add(lblNewLabel);
		calc.getContentPane().add(btn7);
		calc.getContentPane().add(btn8);
		calc.getContentPane().add(btn9);
		calc.getContentPane().add(sum);
		calc.getContentPane().add(btn4);
		calc.getContentPane().add(btn5);
		calc.getContentPane().add(btn1);
		calc.getContentPane().add(btn2);
		calc.getContentPane().add(btn0);
		calc.getContentPane().add(btn6);
		calc.getContentPane().add(btn3);
		calc.getContentPane().add(tseg);
		calc.getContentPane().add(hasah);
		calc.getContentPane().add(multiple);
		calc.getContentPane().add(hubaah);
		calc.getContentPane().add(tensuu);
		calc.getContentPane().add(on);
		calc.getContentPane().add(off);
		calc.getContentPane().add(btnB);
		calc.getContentPane().add(btnPow);
		calc.getContentPane().add(btnSqrt);
		calc.getContentPane().add(btnC);
	}
}
